package sourcemapper

import (
	"fmt"
	"github.com/arduino/go-paths-helper"
	"go.bug.st/lsp"
	"testing"
)

func noduMapperFixture(t *testing.T) (*SketchMapper, lsp.DocumentURI) {
	t.Helper()
	file := paths.New(t.TempDir()).Join("unicode.ino").Canonical()
	text := fmt.Sprintf("#line 1 %q\nvoid setup();\n#line 3 %q\nvoid loop();\n#line 1 %q\nvoid setup() {\n}\nvoid loop() {\n}\n", file.String(), file.String(), file.String())
	return CreateInoMapper([]byte(text)), lsp.NewDocumentURIFromPath(file)
}

func TestNoduDirtyInsertionStillUpdatesEveryLine(t *testing.T) {
	mapper, uri := noduMapperFixture(t)
	dirty := mapper.ApplyTextChange(uri, lsp.TextDocumentContentChangeEvent{Range: &lsp.Range{Start: lsp.Position{Line: 0, Character: 0}, End: lsp.Position{Line: 0, Character: 0}}, Text: "// 中文 😀\n// second\n"})
	if !dirty {
		t.Fatal("prototype insertion should be dirty")
	}
	for ino, cpp := range map[int]int{0: 5, 1: 6, 2: 7, 3: 8, 4: 9, 5: 10, 6: 11} {
		if got, ok := mapper.InoToCppLineOk(uri, ino); !ok || got != cpp {
			t.Errorf("ino %d mapped to %d,%v; want %d", ino, got, ok, cpp)
		}
	}
}

func TestNoduDirtyDeletionRemovesStaleMappings(t *testing.T) {
	mapper, uri := noduMapperFixture(t)
	dirty := mapper.ApplyTextChange(uri, lsp.TextDocumentContentChangeEvent{Range: &lsp.Range{Start: lsp.Position{Line: 0, Character: 0}, End: lsp.Position{Line: 2, Character: 0}}, Text: ""})
	if !dirty {
		t.Fatal("prototype deletion should be dirty")
	}
	for ino, cpp := range map[int]int{0: 5, 1: 6, 2: 7} {
		if got, ok := mapper.InoToCppLineOk(uri, ino); !ok || got != cpp {
			t.Errorf("ino %d mapped to %d,%v; want %d", ino, got, ok, cpp)
		}
	}
	if got, ok := mapper.InoToCppLineOk(uri, 3); ok {
		t.Fatalf("removed trailing source line still maps to cpp %d", got)
	}
}
