# Nodu modifications to Arduino Language Server 0.7.7

2026-10-27; version 0.7.7-nodu.1.

* go.bug.st/lsp v0.1.3 textedits.GetOffset counts LSP UTF-16 code units and returns UTF-8 offsets; clamps columns to their own LF/CRLF line and rejects split surrogate pairs.
* sourcemapper.ApplyTextChange always updates each inserted/deleted line even once dirty=true.
* Added regression tests in sourcemapper/nodu_multiline_test.go and vendor/go.bug.st/lsp/textedits/nodu_utf16_test.go.

No changes to Arduino preprocessing, rebuild timing, hardware/toolchain selection or protocol capabilities. See the adjacent nodu-utf16-mapper.patch and reproducible build-arduino-language-server.cjs. All original source and dependency licenses are retained.
